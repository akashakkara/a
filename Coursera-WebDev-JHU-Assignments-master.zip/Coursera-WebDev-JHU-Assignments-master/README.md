# Coursera-WebDev-JHU-Assignments

### HTML, CSS, JavaScript for Web Developers
#### Johns Hopkins University
##### Coursera
---
This repository contains my solutions to the Module - 2, 3, 4 Coding Assignments for the course HTML, CSS, JavaScript for Web Developers by Johns Hopkins University on Coursera. 

---
**Assignment Links:**

- [Module 2 Assignment](http://goo.gl/4Blt4G)

- [Module 3 Assignment](http://bit.ly/1mKZzJ5)

- [Module 4 Assignment](http://bit.ly/21StgWz)

- [Module 5 Assignment](http://bit.ly/1UWgPJ1)

Mockup illustrations are present in the Assignment documents.


**Solution Links:**

- [Module 2 Solution](http://faheemzunjani.github.io/Coursera-WebDev-JHU-Assignments/module-2-solution/index.html)
- [Module 3 Solution](http://faheemzunjani.github.io/Coursera-WebDev-JHU-Assignments/module-3-solution/index.html)
- [Module 4 Solution](http://faheemzunjani.github.io/Coursera-WebDev-JHU-Assignments/module-4-solution/index.html)
- [Module 5 Solution](http://faheemzunjani.github.io/Coursera-WebDev-JHU-Assignments/module-5-solution/index.html)
